//
//  ViewController.swift
//  Activdad 2 Prototipo y pantalla de navegación
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

